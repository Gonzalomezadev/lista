A Pen created at CodePen.io. You can find this one at http://codepen.io/toto99/pen/ExGwA.

 A bunch of different animation effects for the [Magnific Popup](http://dimsemenov.com/plugins/magnific-popup/)